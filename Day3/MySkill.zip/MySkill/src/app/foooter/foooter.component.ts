import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-foooter',
  templateUrl: './foooter.component.html',
  styleUrls: ['./foooter.component.css']
})
export class FoooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
