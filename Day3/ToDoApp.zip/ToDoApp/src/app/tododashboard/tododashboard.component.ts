import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tododashboard',
  templateUrl: './tododashboard.component.html',
  styleUrls: ['./tododashboard.component.css']
})
export class TododashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
